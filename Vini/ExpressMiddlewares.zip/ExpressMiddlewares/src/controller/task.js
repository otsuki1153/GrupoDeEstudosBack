import TaskService from '../service/task.service.js'

// export function GetControll(req, res) {
//     const Objlist = GetService();
//     res.json(Objlist);
// }

// export function SearchControll(req, res) {
//     const ParamId = parseInt(req.params.id);

//     if (isNaN(ParamId)) {
//         return res.status(400).send("ID inválido");
//     }

//     const Objlist = SearchService(ParamId);

//     if (Objlist === null) {
//         return res.status(404).send("Tarefa não encontrada");
//     } else {
//         res.json(Objlist);
//     }
// }

// export function PostControll(req, res) {
//     const JSONtitle = req.body.title;
//     // if(JSONtitle === null){
//     //     return res.status(400).send("Corpo incompleto");
//     // }
//     const PostedOBJ = PostService(JSONtitle);
//     res.status(201).json(PostedOBJ);
// }

// export function PutControll(req, res) {
//     const ParamId = parseInt(req.params.id);
//     if (isNaN(ParamId)) {
//         return res.status(400).send("ID inválido");
//     }
//     const JSONbody = req.body;
//     const AlteredOBJ = PutService(JSONbody, ParamId);

//     if (AlteredOBJ === null) {
//         return res.status(404).send("Tarefa não encontrada");
//     } else {
//         res.json(AlteredOBJ);
//     }
// }

// export function DeleteControll(req, res) {
//     const ParamId = parseInt(req.params.id);
//     if (isNaN(ParamId)) {
//         return res.status(400).send("ID inválido");
//     }
//     const ItemDeleted = DeleteService(ParamId);

//     if (!ItemDeleted) {
//         res.status(404).send("Tarefa não encontrada");
//     } else {
//         res.status(204).send();
//     }
// }


class TaskController {
    service;

    constructor() {
        this.service = new TaskService();
    }

    GetControll(req, res) {
        const Objlist = this.service.GetService();
        res.json(Objlist);
    }

    SearchControll(req, res) {
        const ParamId = parseInt(req.params.id);

        if (isNaN(ParamId)) {
            return res.status(400).send("ID inválido");
        }

        const Objlist = this.service.SearchService(ParamId);

        if (Objlist === null) {
            return res.status(404).send("Tarefa não encontrada");
        } else {
            res.json(Objlist);
        }
    }

    PutControll(req, res) {
        const ParamId = parseInt(req.params.id);
        if (isNaN(ParamId)) {
            return res.status(400).send("ID inválido");
        }
        const JSONbody = req.body;
        const AlteredOBJ = this.service.PutService(JSONbody, ParamId);

        if (AlteredOBJ === null) {
            return res.status(404).send("Tarefa não encontrada");
        } else {
            res.json(AlteredOBJ);
        }
    }

    DeleteControll(req, res) {
        const ParamId = parseInt(req.params.id);
        if (isNaN(ParamId)) {
            return res.status(400).send("ID inválido");
        }
        const ItemDeleted = this.service.DeleteService(ParamId);

        if (!ItemDeleted) {
            res.status(404).send("Tarefa não encontrada");
        } else {
            res.status(204).send();
        }
    }

    PostControll(req, res) {
        const JSONtitle = req.body.title;
        if (JSONtitle === null) {
            return res.status(400).send("Corpo incompleto");
        }
        const PostedOBJ = new TaskService().PostService(JSONtitle);
        res.status(201).json(PostedOBJ);
    }
}

export default TaskController;