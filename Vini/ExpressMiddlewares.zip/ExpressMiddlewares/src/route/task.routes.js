import {Router} from "express";
import TaskController from "../controller/task.js";

const route = Router();

const controller = new TaskController();

route.get("/", controller.GetControll);

route.get("/:id", controller.SearchControll);

route.post("/", controller.PostControll);

route.put("/:id", controller.PutControll);

route.delete("/:id", controller.DeleteControll);

export default route;