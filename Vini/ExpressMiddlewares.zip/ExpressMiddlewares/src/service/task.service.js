

class TaskService {
    tarefas = new Array();
    NextId = 0;

    GetService() {
        return this.tarefas;
    }

    SearchService(ParamId) {
        const index = this.tarefas.findIndex(t => t.id === ParamId);

        if (index === -1) {
            return null;
        }
        return this.tarefas[index];
    }

    PostService(title) {
        const processedMsg = {
            "id": this.NextId,
            "title": title
        }

        this.tarefas.push(processedMsg);
        this.NextId++;
        return processedMsg;
    }

    PutService(OBJ, ParamId) {
        const index = this.tarefas.findIndex(t => t.id === ParamId);

        if (index === -1) {
            return null;
        }

        tarefas[index] = {
            ...this.tarefas[index],
            ...OBJ
        }
        return this.tarefas[index];
    }

    DeleteService(ParamId) {
        const index = this.tarefas.findIndex(t => t.id === ParamId);

        if (index === -1) {
            return false;
        }

        this.tarefas.splice(index, 1);

        return true;
    }

}

export default TaskService;

// export function GetService() {
//     return tarefas;
// }

// export function SearchService(ParamId) {
//     const index = tarefas.findIndex(t => t.id === ParamId);

//     if (index === -1) {
//         return null;
//     }
//     return tarefas[index];
// }

// export function PostService(title) {
//     const processedMsg = {
//         "id": NextId,
//         "title": title
//     }

//     tarefas.push(processedMsg);
//     NextId++;
//     return processedMsg;
// }

// export function PutService(OBJ, ParamId) {
//     const index = tarefas.findIndex(t => t.id === ParamId);

//     if (index === -1) {
//         return null;
//     }

//     tarefas[index] = {
//         ...tarefas[index],
//         ...OBJ
//     }
//     return tarefas[index];
// }

// export function DeleteService(ParamId) {
//     const index = tarefas.findIndex(t => t.id === ParamId);

//     if (index === -1) {
//         return false;
//     }

//     tarefas.splice(index, 1);

//     return true;
// }
