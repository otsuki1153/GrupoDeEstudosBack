import express from "express";
import rateLimit from "express-rate-limit";
import LoggerMiddleware from "./src/middleware/logger.middleware.js"
import helmet from "helmet";
import validationMiddleware from './src/middleware/validation.middleware.js';
import cors from "cors";
import TaskRouter from "./src/route/task.routes.js"
import notFound from "./src/middleware/notFound.middleware.js"
import error from "./src/middleware/error.middleware.js"

const app = express();
const PORT = 3000;

const corsOp = {
    origin: `http://localhost:${PORT}`
};

const limit = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 100
});

app.use(express.json());
// app.use(LoggerMiddleware.execute);
app.use(helmet());
app.use(cors(corsOp));
app.use(limit);
// app.use(validationMiddleware);


app.use("/tasks", TaskRouter);

// app.use(notFound);
// app.use(error);

app.listen(PORT, () =>{
    console.log(`API rodando na porta ${PORT}`)
});
